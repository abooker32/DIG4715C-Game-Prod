﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class npcMove : MonoBehaviour {

    public Transform[] waypoints;
    public int destination;
    public NavMeshAgent agent;
    public GameObject player;

    private bool playerDetected = false;
    private bool playerCaught = false;
    //private IEnumerator detection;
    private Vector3 stopPos;

	// Use this for initialization
	void Start ()
    {

        agent = GetComponent<NavMeshAgent>();

        SetSpeed();

        SetDestination();

    }

    // Update is called once per frame
    private void Update () {
        if (!playerDetected)
        {
            // Checks if the npc has a path and calls the SetDestination function
            if (!agent.pathPending && agent.remainingDistance < 0.1f)
            {
                SetDestination();
            }
        }
        else if (!playerCaught)
        {
            //Sets the npc destination to the player and increases its speed
            agent.destination = player.transform.position;
            SetSpeed();
            Debug.Log("Player Found");
        }
        
        //Tells the npc to not cast a ray on the obstacle layer
        int layerMask = 1 << 11;
        layerMask = ~layerMask;
        
        //Detects if the npc has detected the player
    
        if (!playerCaught)
        {
            RaycastHit hit;
            if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit, 25, layerMask))
            {
                Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward) * hit.distance, Color.yellow);
                if (hit.transform.gameObject.tag == "Player")
                {
                    //StartCoroutine(detection);
                    playerDetected = true;
                }
            }
            else
            {
                Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward) * 25, Color.red);
            }
        }
    }

    private void FixedUpdate()
    {
        if (Input.GetKeyDown("escape"))
        {
            Application.Quit();
        }
    }

    private void SetDestination()
    {
        //Sets the destination of the npc to waypoints
        agent.destination = waypoints[destination].position;

        destination = (destination + 1) % waypoints.Length;
    }

    //Sets the speed of the npc
  private void SetSpeed()
    {
        if (!playerDetected)
        {
            agent.speed = 4;
        }
        else
        {
            agent.speed = 8;
        }
    }

    //Flags the player as caught after it has collided with the npc
  private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            playerCaught = true;
            stopPos = transform.position;
            agent.destination = (stopPos);
            agent.isStopped = true;
            Debug.Log("Player Caught");
        }

    }

    /*IEnumerator detection()
    {

    } */
}
